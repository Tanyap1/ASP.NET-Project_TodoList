<h1>COMP 2084 - ToDo List </h1>
<p>This is the ASP. NET Project for Summer 2021 </p>
<p>This is a To Do List where you can create a new Task or edit the existing one </p>
<footer>
    <p><small>This website contains some photos from<a href="https://blog.lulu.com/to-do-list/">Here!</a></small></p>
    <p><small>Logo made at <a href=" https://looka.com" target="_blank">Looka.com</a> </small></p>
</footer>