﻿using System;

namespace ToDoList.Models
{
    internal class requiredAttribute : Attribute
    {
    }
}